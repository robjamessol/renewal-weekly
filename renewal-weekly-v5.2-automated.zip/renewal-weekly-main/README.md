# Renewal Weekly Newsletter Compiler v5.2

A React-based tool for compiling weekly health newsletters focused on stem cell therapy, regenerative medicine, and longevity.

## 🎯 Target Audience
Adults aged 40-80 with degenerative conditions interested in:
- Stem cell therapy
- Regenerative medicine
- Anti-aging and longevity
- Clinical trials

## 🚀 Quick Start

```bash
npm install
npm run dev
```

## ⚙️ API Setup (Required for AI Features)

The "Create Newsletter" button uses Claude AI to generate content. To enable it:

### 1. Get an Anthropic API Key
Visit [console.anthropic.com](https://console.anthropic.com/) to get your API key.

### 2. Add to Vercel Environment Variables
1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Select your project
3. Go to **Settings** → **Environment Variables**
4. Add a new variable:
   - **Key**: `ANTHROPIC_API_KEY`
   - **Value**: `sk-ant-api03-...` (your full API key)
5. Click **Save**
6. **Redeploy** your project for changes to take effect

### Cost Estimate
- ~$0.15-0.25 per full newsletter generation
- Uses Claude 3.5 Sonnet with web search for current news

## 📋 16-Section Newsletter Structure

| # | Section | Purpose |
|---|---------|---------|
| 1 | Opening Hook | Seasonal, friendly greeting (50-75 words) |
| 1b | The Bottom Line | TL;DR for scanners (4 bullet points) |
| 2 | Metrics Dashboard | 3×2 grid with industry stats |
| 3 | Lead Story | Main article with hero image (350-400 words) |
| 4 | Research Roundup | Treatment spotlight (100-150 words) |
| 5 | Sponsor 1 | Placeholder for sponsor |
| 6 | On Our Radar | 3 secondary stories |
| 7 | Deep Dive | Nutrition/lifestyle article (200-250 words) |
| 8 | Sponsor 2 | Placeholder for sponsor |
| 9 | Worth Knowing | Red flags, guides, resources |
| 10 | Stat of the Week | Big number storytelling (150-200 words) |
| 11 | The Pulse | 7 quick hits with sources |
| 12 | RECS | Read/Watch/Try/Listen recommendations |
| 13 | PLAY | Rotating health trivia game |
| 14 | Referral | Beehiiv referral program |
| 15 | Footer | Game answer + Word of the Day |

## 🎨 Brand Colors

| Role | Hex Code |
|------|----------|
| Primary Purple | `#7C3AED` |
| Secondary Violet | `#5B21B6` |
| Accent Lavender | `#EDE9FE` |
| Link Underline | `#8B5CF6` |
| Dark (headers) | `#1E1B4B` |
| Text | `#1F2937` |

## 🔗 In-Text Link Syntax

Use this syntax in content:
```
{{LINK:display text|https://example.com}}
```

Example:
```
Researchers at {{LINK:Stanford University|https://stanford.edu}} published...
```

Renders as clickable link with purple underline.

## 🤖 AI Features

- **"Create Newsletter"** - Generates complete newsletter with real-time web research
- **6-day freshness filter** - Only uses content published in the last week
- **Duplicate prevention** - Tracks headlines from recent issues to avoid repetition
- **Section refresh** - Regenerate individual sections with custom prompts
- **Live web search** - All sources link to specific articles, not homepages

## 📤 Beehiiv Export

The HTML tab generates Beehiiv-ready code with:
- Proper styling preserved
- Merge tags: `{{subscriber.referral_count}}`, `{{subscriber.rh_reflink}}`
- Image placeholders marked `[YOUR_IMAGE_URL]`

## 📁 Key Files

- `src/App.jsx` - Main application
- `api/generate-section.js` - Vercel serverless function for AI generation
- `CONTEXT.md` - Full project specifications
- `STYLE-GUIDE.md` - Writing style guide
- `WEEKLY-PROMPTS.md` - AI prompts for weekly content

## 🔄 Weekly Workflow

1. **Wednesday Morning**: Open app, click "Create Newsletter"
2. **Review Content**: AI generates all sections with current news
3. **Edit & Refine**: Customize each section as needed
4. **Preview**: Check full newsletter in Preview tab
5. **Export**: Copy HTML to Beehiiv
6. **Add Images**: Use Midjourney prompts provided
7. **Thursday Morning**: Send newsletter

## 📊 Features

- ✅ **Automated content generation** with Claude AI + web search
- ✅ **6-day freshness filter** - only recent news
- ✅ **Duplicate prevention** - tracks headlines across issues
- ✅ Story tracking (prevents repeating content)
- ✅ 8 rotating trivia games
- ✅ Custom news sources
- ✅ Image slot management with Midjourney prompts
- ✅ Section-by-section copy buttons
- ✅ Full HTML export
- ✅ localStorage persistence
- ✅ Newsletter history (last 20 issues)

## 🛠️ Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📁 Project Structure

```
renewal-weekly/
├── api/
│   └── generate-section.js    # Vercel serverless function
├── src/
│   ├── App.jsx                # Main React app
│   ├── main.jsx               # Entry point
│   └── index.css              # Tailwind styles
├── CONTEXT.md                 # Project specifications
├── STYLE-GUIDE.md             # Writing style guide
├── WEEKLY-PROMPTS.md          # AI prompts
├── vercel.json                # Vercel configuration
└── package.json
```

## 📝 License

Private project for Renewal Weekly newsletter.
