// Vercel Serverless Function for Newsletter Section Generation
// This runs on the server, keeping your API key secure

export default async function handler(req, res) {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Get API key from environment variable (set in Vercel dashboard)
  const apiKey = process.env.ANTHROPIC_API_KEY;
  
  if (!apiKey) {
    return res.status(500).json({ 
      error: 'API key not configured. Add ANTHROPIC_API_KEY to Vercel environment variables.',
      help: 'Go to Vercel Dashboard → Your Project → Settings → Environment Variables'
    });
  }

  const { sectionType, customPrompt, enabledSources, usedHeadlines } = req.body;

  if (!sectionType) {
    return res.status(400).json({ error: 'sectionType is required' });
  }

  const today = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric', 
    year: 'numeric' 
  });

  // Calculate the date 6 days ago for freshness filter
  const sixDaysAgo = new Date();
  sixDaysAgo.setDate(sixDaysAgo.getDate() - 6);
  const freshDate = sixDaysAgo.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  const sourcesText = enabledSources?.join(', ') || 'ScienceDaily, Nature, Cell Stem Cell, STAT News, PubMed';
  
  // Build a list of headlines to avoid (for duplicate prevention)
  const avoidHeadlines = usedHeadlines?.length > 0 
    ? `\n\nCRITICAL - DO NOT write about these topics (already covered in recent issues):\n${usedHeadlines.map(h => `- ${h}`).join('\n')}\n\nFind COMPLETELY DIFFERENT stories.`
    : '';

  const styleContext = `You are writing for Renewal Weekly, a newsletter about stem cells and regenerative medicine.

CRITICAL OUTPUT RULES:
- DO NOT include ANY preamble, thinking, or explanations
- DO NOT say "Let me search..." or "Based on my search..." or similar
- Output ONLY the final content - nothing else
- Start directly with the headline or content requested
- If returning JSON, return ONLY valid JSON - no text before or after

FRESHNESS REQUIREMENT:
- ONLY use news/research published AFTER ${freshDate} (within the last 6 days)
- If you can't find content from the last 6 days, search harder or use a different angle
- Never use content older than 1 week${avoidHeadlines}

WRITING STYLE:
- Voice: Smart friend who reads medical journals—hopeful but never naive
- Tone: Confident not preachy, direct not clinical
- Structure: Use "Here's what happened:" / "Why this matters:" / "The catch:" labels where appropriate
- Always include costs, availability, and limitations when discussing treatments
- Follow technical info with plain-English translation
- Audience: Adults 40-80 with chronic conditions, smart and skeptical of hype

CRITICAL LINK REQUIREMENTS:
- Embed ALL links using this exact syntax: {{LINK:display text|url}}
- EVERY source MUST link to the SPECIFIC ARTICLE, not a homepage
- Example: {{LINK:Stanford Medicine|https://med.stanford.edu/news/all-news/2025/11/specific-article.html}} ✓
- NOT: {{LINK:Stanford Medicine|https://med.stanford.edu}} ✗
- Include the publication date when available

TODAY'S DATE: ${today}
PRIORITY SOURCES: ${sourcesText}`;

  const sectionPrompts = {
    openingHook: `${styleContext}

Search the web for current events, weather, seasonal information for today (${today}).

Write an opening hook (50-75 words) for today's newsletter.
- Make it seasonal/timely for TODAY'S date
- Warm, slightly humorous, relatable
- Do NOT mention stem cells or medical content in the hook
- End with "—The Renewal Weekly Team"
Pattern: Observation → Gentle reframe → "We'll handle the health intel. You handle [something relatable]."
${customPrompt ? `\nTopic focus: ${customPrompt}` : ''}`,

    leadStory: `${styleContext}

Search the web for the LATEST stem cell or regenerative medicine news from the past 6 days ONLY. Find a significant breakthrough, clinical trial result, or major development published AFTER ${freshDate}.

Write a lead story (350-400 words) about what you find.
Structure:
1. Headline (clever but clear, no clickbait)
2. Opening: "[X million] Americans with [condition]... That changed this week."
3. "Here's what happened:" section with specifics from the actual article
4. "Why this matters now:" context and implications
5. "What's next:" forward-looking statement
6. "Zoom out:" connection to bigger picture

IMPORTANT: Include 2-3 {{LINK:display text|url}} embedded links to the ACTUAL articles you found.
${customPrompt ? `\nTopic focus: ${customPrompt}` : ''}`,

    researchRoundup: `${styleContext}

Search the web for recent news about stem cell treatments or regenerative therapies from the past 6 days. Find a specific treatment or therapy with new research.

Write a Research Roundup (100-150 words) about what you find.
Structure:
- "If you or someone you love has [condition], this one's worth reading twice."
- What the research found (2-3 sentences with specifics)
- "What you should know:" (cost range, availability, insurance status if mentioned)
- "The catch:" (honest limitation from the research)
- "Bottom line:" (actionable next step)

Include {{LINK:source|url}} linking to the SPECIFIC article.
${customPrompt ? `\nFocus: ${customPrompt}` : ''}`,

    secondaryStories: `${styleContext}

Search the web for 3 DIFFERENT recent stem cell or regenerative medicine news stories from the past 6 days. Find diverse topics that haven't been covered in the lead story.

Write 3 secondary news stories.
Each story needs:
- Bold lead sentence that hooks (pattern: [Subject] + [did what] + [surprising element])
- 75-150 words expanding on it with REAL facts from the article
- The actual source URL and publication date

Return as JSON array: [{"boldLead": "...", "content": "...", "sources": [{"title": "Source Name", "url": "https://actual-article-url.com/specific-article", "date": "Nov 26, 2025"}]}]

IMPORTANT: Each source URL must be the direct link to the article, NOT a homepage.`,

    deepDive: `${styleContext}

Search the web for recent research about nutrition, lifestyle, or wellness connected to regenerative health, longevity, or cellular health from the past 2 weeks.

Write a Deep Dive (200-250 words) about what you find.
Structure:
- Contrarian opening: "The [industry] wants you to believe [X]. [Source] disagrees."
- Evidence with bullet points (use • not -)
- "The connection to stem cells:" paragraph explaining why this matters for cellular health
- Actionable takeaway

Include {{LINK:source|url}} links to the ACTUAL articles.
${customPrompt ? `\nTopic: ${customPrompt}` : ''}`,

    statSection: `${styleContext}

Search the web for a compelling statistic about regenerative medicine, stem cell research, or the biotech industry from recent reports or studies.

Create a Stat of the Week based on what you find.
Format as JSON:
{
  "primeNumber": "The big stat (e.g., '$403.86B' or '67%')",
  "headline": "what it represents (lowercase, e.g., 'where the regenerative medicine market is headed by 2032')",
  "content": "150-200 words with context, scale comparisons, and 'Why it matters for you:' section. Include {{LINK:text|url}} to the source article."
}`,

    thePulse: `${styleContext}

Search the web for 7 quick news items about: stem cells, regenerative medicine, clinical trials, biotech industry, and health innovation from the past 6 days.

Write 7 quick hits for The Pulse section.
- Each under 25 words
- Mix: 3-4 stem cell/regenerative items, 1-2 trial updates, 1 industry news, 1 surprising health fact
- Each MUST include a {{LINK:text|url}} to the actual article

Return as JSON array of objects: [{"text": "content with {{LINK:text|url}} embedded", "source": "Source Name", "url": "full-url", "date": "Nov 26, 2025"}]`,

    recommendations: `${styleContext}

Based on the theme of regenerative medicine and stem cells, search for interesting content to recommend this week.

Find and return JSON with recommendations in these categories:
{
  "read": {"prefix": "text before link", "linkText": "linked text", "suffix": "text after link", "url": "actual-article-url"},
  "watch": {"prefix": "", "linkText": "", "suffix": "", "url": ""},
  "try": {"prefix": "", "linkText": "", "suffix": "", "url": ""},
  "listen": {"prefix": "", "linkText": "", "suffix": "", "url": ""}
}

Find REAL, current content:
- Read: A scientific paper, article, or in-depth piece about regenerative medicine
- Watch: A documentary, lecture, or video about health/science
- Try: A health practice, app, or lifestyle recommendation
- Listen: A podcast episode about health, longevity, or medical innovation

URLs must be direct links to the specific content, not homepages.`,

    bottomLine: `${styleContext}

Write 4 bullet points for "The Bottom Line" (TL;DR section).

Search for the latest stem cell and regenerative medicine news from the past 6 days.

FORMAT:
→ [Key takeaway 1 - about stem cell/regenerative medicine news this week]
→ [Key takeaway 2 - about a different important development]
→ [Key takeaway 3 - practical insight for readers]
→ [Key takeaway 4 - forward-looking or surprising fact]

Each bullet: One clear insight, under 20 words, punchy and benefit-focused.
Focus on REAL developments from the past 6 days.

Return as JSON array of 4 strings (without the → symbol):
["first point", "second point", "third point", "fourth point"]`,

    worthKnowing: `${styleContext}

Create 3 items for "Worth Knowing" section.

ITEM 1 - Upcoming awareness/event:
- Health awareness day or medical event in next 2 weeks
- Real date and what readers can do (free screenings, etc.)

ITEM 2 - Red flags or guide:
- Practical protection for health consumers
- Examples: "5 Questions to Ask Before..." or "Red Flags When Choosing..."
- Specific, actionable tips

ITEM 3 - Resource:
- Helpful tool or resource with real link
- ClinicalTrials.gov search tip, reliable information source, etc.

Return as JSON:
[
  {"type": "awareness", "title": "...", "date": "December X", "description": "2-3 sentences", "link": null},
  {"type": "guide", "title": "5 Red Flags When...", "date": "", "description": "the 5 items listed", "link": "real url if applicable"},
  {"type": "resource", "title": "...", "date": "", "description": "what it is and why useful", "link": "real url"}
]`,

    wordOfDay: `You are writing for Renewal Weekly, a newsletter about stem cells and regenerative medicine.

Select a Word of the Day - a medical/scientific term related to stem cells, regenerative medicine, or longevity.

Requirements:
- Impressive but explainable to general audience
- Not too basic (not "stem cell") but not too obscure
- Related to current regenerative medicine topics

Return as JSON:
{
  "word": "Word",
  "definition": "clear, accessible definition without jargon",
  "suggestedBy": "a first name",
  "location": "City, ST"
}`,

    gameTrivia: `Create an engaging trivia game for a health newsletter. The game should have BROAD APPEAL - it doesn't need to be about stem cells or medicine specifically.

Think of fun categories like:
- Food/nutrition facts
- Body facts and numbers
- Health myths vs facts
- Calorie guessing games
- Ingredient identification
- Famous health quotes
- Historical health facts

Return as JSON:
{
  "title": "Game title",
  "intro": "Brief intro explaining the game (1-2 sentences)",
  "content": "The actual game content with questions/prompts",
  "answer": "The answers"
}

Make it fun, surprising, and educational!`
  };

  const prompt = sectionPrompts[sectionType] || customPrompt;

  if (!prompt) {
    return res.status(400).json({ error: `Unknown section type: ${sectionType}` });
  }

  try {
    // Determine if we need web search (most sections do, except word of day and games)
    const needsWebSearch = !['wordOfDay', 'gameTrivia'].includes(sectionType);

    const requestBody = {
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2000,
      messages: [{
        role: 'user',
        content: prompt
      }]
    };

    if (needsWebSearch) {
      requestBody.tools = [{
        type: 'web_search_20250305',
        name: 'web_search',
        max_uses: 5
      }];
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('Anthropic API Error:', error);
      return res.status(response.status).json({ 
        error: error.error?.message || 'API request failed',
        details: error
      });
    }

    const data = await response.json();

    // Extract text content from the response
    let content = '';
    for (const block of data.content) {
      if (block.type === 'text') {
        content += block.text;
      }
    }

    // Calculate approximate cost (Claude 3.5 Sonnet pricing)
    const inputTokens = data.usage?.input_tokens || 0;
    const outputTokens = data.usage?.output_tokens || 0;
    const estimatedCost = (inputTokens * 0.003 / 1000) + (outputTokens * 0.015 / 1000);

    return res.status(200).json({ 
      content,
      usage: data.usage,
      estimatedCost: `$${estimatedCost.toFixed(4)}`
    });

  } catch (error) {
    console.error('Server error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}
